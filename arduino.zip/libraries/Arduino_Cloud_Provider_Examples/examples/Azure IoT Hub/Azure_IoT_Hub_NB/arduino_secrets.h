// NB settings
#define SECRET_PINNUMBER ""

// Fill in the hostname of your Azure IoT Hub broker
#define SECRET_BROKER    "<hub name>.azure-devices.net"

// Fill in the device id
#define SECRET_DEVICE_ID "<device id>"
